Wireless Battery - Experimental Xbox + HyperX Test Build

Included fixes:
- Multiple Xbox controllers with identical Bluetooth names
- HyperX Cloud Flight S (0951:16EA / 0951:16EB)

HOW TO TEST

1. Exit the installed Wireless Battery app from the system tray.
2. Extract the ZIP to a folder, for example Downloads.
3. Connect both Xbox controllers via Bluetooth.
4. Connect the HyperX Cloud Flight S USB dongle.
5. Open PowerShell.
6. Run the EXE from the extracted folder.

Example:

& "$env:USERPROFILE\Downloads\WirelessBattery-Xbox-HyperX-Test\WirelessBattery.exe" --list

Alternatively, open PowerShell inside the extracted folder and run:

.\WirelessBattery.exe --list

7. Send the output or screenshot to the developer.

No installation required.
Do not replace your existing installation.

This is an unofficial, unsigned experimental build.
